// Copyright Epic Games, Inc. All Rights Reserved.

#include "DemoCppSimple.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, DemoCppSimple, "DemoCppSimple" );
