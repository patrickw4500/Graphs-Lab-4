// Copyright Epic Games, Inc. All Rights Reserved.

#include "MyProject5.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, MyProject5, "MyProject5" );
