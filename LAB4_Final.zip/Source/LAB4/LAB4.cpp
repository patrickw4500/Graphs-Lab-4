// Copyright Epic Games, Inc. All Rights Reserved.

#include "LAB4.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, LAB4, "LAB4" );
